package com.luis.annoyingmouse;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setBackgroundColor(0xFF172033);

        TextView title = new TextView(this);
        title.setText("🐭  ANNOYING MOUSE");
        title.setTextSize(25);
        title.setTextColor(0xFFFFFFFF);
        layout.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Tu ratón pixelado vive encima de la pantalla. Arrástralo y deja que haga alguna travesura.");
        intro.setTextSize(16); intro.setTextColor(0xFFE5E7EB);
        intro.setPadding(0, 22, 0, 22);
        layout.addView(intro);

        Button overlay = button("1. Permitir mostrar sobre otras apps");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else toast("Permiso de ventana flotante ya concedido.");
        });
        layout.addView(overlay);

        Button accessibility = button("2. Activar permiso de Accesibilidad");
        accessibility.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(accessibility);

        Button start = button("3. Sacar al ratón");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                toast("Primero concede el permiso de ventana flotante.");
                return;
            }
            Intent i = new Intent(this, MouseOverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            toast("¡El ratón ha salido!");
        });
        layout.addView(start);

        Button mischief = button("Activar / desactivar travesuras");
        mischief.setOnClickListener(v -> {
            boolean enabled = !getSharedPreferences("mouse", MODE_PRIVATE)
                .getBoolean("mischief", false);
            getSharedPreferences("mouse", MODE_PRIVATE).edit()
                .putBoolean("mischief", enabled).apply();
            MouseAccessibilityService.setMischiefEnabled(enabled);
            toast(enabled ? "Travesuras activadas." : "Travesuras desactivadas.");
        });
        layout.addView(mischief);

        Button stop = button("Guardar al ratón");
        stop.setOnClickListener(v -> {
            getSharedPreferences("mouse", MODE_PRIVATE).edit()
                .putBoolean("mischief", false).apply();
            MouseAccessibilityService.setMischiefEnabled(false);
            stopService(new Intent(this, MouseOverlayService.class));
            toast("Ratón guardado y travesuras desactivadas.");
        });
        layout.addView(stop);

        status = new TextView(this);
        status.setText("Las travesuras pueden enviarte a Inicio de forma aleatoria. Requieren que actives Accesibilidad y el interruptor de travesuras.");
        status.setTextColor(0xFFFFD166); status.setTextSize(14);
        status.setPadding(0, 24, 0, 0);
        layout.addView(status);
        setContentView(layout);
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8); b.setLayoutParams(p); return b;
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
