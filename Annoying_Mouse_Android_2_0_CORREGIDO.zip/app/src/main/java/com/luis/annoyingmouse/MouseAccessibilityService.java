package com.luis.annoyingmouse;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;
import java.util.Random;

public class MouseAccessibilityService extends AccessibilityService {
    private static MouseAccessibilityService instance;
    private static volatile boolean enabled = false;
    private final Handler handler = new Handler();
    private final Random random = new Random();
    private final Runnable prank = new Runnable() {
        @Override public void run() {
            if (enabled && instance == MouseAccessibilityService.this) {
                // Solo ejecuta la acción global Inicio; no toca botones ni cuentas.
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
            scheduleNext();
        }
    };
    public static void setMischiefEnabled(boolean value) {
        enabled = value;
        if (instance != null) {
            instance.handler.removeCallbacks(instance.prank);
            if (value) instance.scheduleNext();
        }
    }
    private void scheduleNext() {
        if (enabled) handler.postDelayed(prank, 60000L + random.nextInt(120000));
    }
    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        enabled = getSharedPreferences("mouse", MODE_PRIVATE)
            .getBoolean("mischief", false);
        if (enabled) scheduleNext();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
