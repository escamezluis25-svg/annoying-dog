ANNOYING MOUSE ANDROID 2.0 — PROYECTO PARA COMPILAR APK

Incluye:
- Mascota flotante arrastrable sobre otras aplicaciones.
- Movimiento aleatorio ocasional.
- Servicio de Accesibilidad opcional que solo puede enviar a Inicio.
- Travesuras desactivadas por defecto.
- Botón para detener la mascota.

COMPILACIÓN EN GITHUB
1. Sube este ZIP al repositorio con el nombre Annoying_Mouse_Android_2_0.zip.
2. Sustituye .github/workflows/build.yml por el archivo github-workflow/build.yml incluido aquí.
3. Abre Actions > Build Annoying Mouse APK > Run workflow.
4. Cuando termine correctamente, descarga el artefacto annoying-mouse-apk.

PERMISOS
- Mostrar sobre otras apps: necesario para la mascota flotante.
- Accesibilidad: solo necesario para la acción Inicio aleatoria.
- Activa las travesuras dentro de la app cuando quieras. Están apagadas inicialmente.

LÍMITES
- La mascota se mueve por la pantalla y se puede arrastrar; no detecta ni escala sobre cada botón/icono.
- La única travesura de Accesibilidad es volver a Inicio. No cierra procesos ni realiza acciones en TikTok.
- Para parar todo, abre Annoying Mouse y pulsa Guardar al ratón; también puedes desactivar Accesibilidad desde Ajustes.

NOTA TÉCNICA
Proyecto Android nativo, Java, Android Gradle Plugin 8.6.1, Gradle 8.7, SDK 35.
