package com.luis.annoyingmouse;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import java.util.Random;

public class MouseOverlayService extends Service {
    private WindowManager wm;
    private ImageView mouse;
    private WindowManager.LayoutParams params;
    private final Handler handler = new Handler();
    private final Random random = new Random();
    private boolean dragging = false;
    private float downX, downY;
    private int startX, startY;

    private final Runnable wander = new Runnable() {
        @Override public void run() {
            if (mouse != null && !dragging) {
                params.x = random.nextInt(Math.max(1, getResources().getDisplayMetrics().widthPixels - 120));
                params.y = random.nextInt(Math.max(1, getResources().getDisplayMetrics().heightPixels - 180));
                try { wm.updateViewLayout(mouse, params); } catch (Exception ignored) {}
            }
            handler.postDelayed(this, 9000 + random.nextInt(9000));
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        startForeground(41, makeNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        mouse = new ImageView(this);
        mouse.setImageResource(com.luis.annoyingmouse.R.drawable.mouse_cursor);
        mouse.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int size = (int)(64 * getResources().getDisplayMetrics().density);
        int type = Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 80; params.y = 260;
        mouse.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true; downX = e.getRawX(); downY = e.getRawY();
                    startX = params.x; startY = params.y; return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = startX + (int)(e.getRawX() - downX);
                    params.y = startY + (int)(e.getRawY() - downY);
                    try { wm.updateViewLayout(mouse, params); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false; return true;
            }
            return false;
        });
        wm.addView(mouse, params);
        handler.postDelayed(wander, 7000);
    }

    private Notification makeNotification() {
        String channel = "annoying_mouse";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(channel, "Annoying Mouse",
                NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ?
            new Notification.Builder(this, channel) : new Notification.Builder(this);
        return b.setContentTitle("Annoying Mouse está suelto")
            .setContentText("Toca Guardar al ratón en la aplicación para detenerlo.")
            .setSmallIcon(android.R.drawable.ic_menu_help).build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (mouse != null) { try { wm.removeView(mouse); } catch (Exception ignored) {} mouse = null; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
