# Annoying Dog Android 0.2

Prototipo Android en Kotlin basado en la hoja de sprites que compartiste.

## Novedades 0.2
- Movimiento automático horizontal.
- Reacción al llegar a los bordes y pequeño intento de trepar.
- Tocar al perro cambia entre comportamiento normal, dormir y carreras.
- Arrastrar para colocarlo donde quieras.
- Travesuras opcionales que intentan abrir la pantalla de Inicio tras intervalos aleatorios.

## Compilar
1. Abre esta carpeta en Android Studio.
2. Usa JDK 17 y Android SDK 35.
3. Sincroniza Gradle.
4. Build > Build APK(s).
5. Instala el APK en Android, concede "Mostrar sobre otras aplicaciones" y pulsa "¡Sacar al perro!".

## Límites y seguridad
Esto es el código fuente, no un APK compilado. Android puede limitar servicios en segundo plano.
La travesura abre la pantalla de Inicio; no mata ni fuerza el cierre de apps. Viene desactivada de inicio y se activa manualmente. No realiza acciones en TikTok ni en otras cuentas.
Los sprites proceden de la imagen aportada por el usuario. Comprueba sus condiciones de uso antes de distribuir la aplicación.

## Compilar automáticamente con GitHub Actions (sin Android Studio)
1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de este ZIP (no el ZIP como único archivo): entra al repositorio, pulsa **Add file > Upload files**, descomprime el proyecto y arrastra sus carpetas y archivos.
3. Asegúrate de que `.github/workflows/android.yml` también se haya subido. En GitHub, los archivos que empiezan por punto pueden ser menos visibles en algunos selectores; activa "mostrar archivos ocultos" si hace falta.
4. Abre la pestaña **Actions** del repositorio.
5. Entra en **Build Annoying Dog APK**. Si aparece el botón **Run workflow**, púlsalo; si no, el primer push a `main` ya inicia la compilación.
6. Cuando termine en verde, abre la ejecución y baja hasta **Artifacts**.
7. Descarga `annoying-dog-debug-apk.zip`, descomprímelo y encontrarás `app-debug.apk`.
8. Pasa el APK al móvil e instálalo. Android puede pedir autorización para instalar apps desde el navegador o gestor de archivos.
