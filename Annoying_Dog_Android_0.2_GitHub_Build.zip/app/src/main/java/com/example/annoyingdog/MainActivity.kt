package com.example.annoyingdog

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("dog", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "🐶 Annoying Dog 0.2"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Tu mascota flotante: arrástrala, tócala para cambiar de comportamiento y activa las travesuras si quieres."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val pranks = Switch(this).apply {
            text = "Travesuras: volver a Inicio aleatoriamente"
            textSize = 15f
            isChecked = prefs.getBoolean("pranks", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("pranks", checked).apply() }
        }
        val permission = Button(this).apply {
            text = "1. Permitir mostrarse sobre otras apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permiso ya concedido", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "2. ¡Sacar al perro!"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Primero concede el permiso de superposición", Toast.LENGTH_LONG).show()
                } else {
                    val i = Intent(this@MainActivity, DogOverlayService::class.java)
                    startForegroundService(i)
                    Toast.makeText(this@MainActivity, "¡El perro ha salido!", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Guardar al perro"
            setOnClickListener { stopService(Intent(this@MainActivity, DogOverlayService::class.java)) }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(pranks)
        layout.addView(stop)
        setContentView(layout)
    }
}
