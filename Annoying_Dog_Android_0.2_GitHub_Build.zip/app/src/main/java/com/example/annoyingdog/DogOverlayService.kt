package com.example.annoyingdog

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import kotlin.random.Random

class DogOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var dog: ImageView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var frame = 0
    private var mode = 0 // 0 walk, 1 nap, 2 zoomies
    private var direction = 1
    private var edgeClimb = false
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var originX = 0
    private var originY = 0
    private var ticks = 0

    private val loop = object : Runnable {
        override fun run() {
            val p = lp
            if (p != null && !dragging) {
                val bounds = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds else
                    android.graphics.Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
                val maxX = (bounds.width() - dp(76)).coerceAtLeast(0)
                val maxY = (bounds.height() - dp(110)).coerceAtLeast(0)
                when (mode) {
                    0 -> {
                        p.x += direction * dp(4)
                        if (p.x <= 0 || p.x >= maxX) {
                            direction *= -1
                            p.x = p.x.coerceIn(0, maxX)
                            edgeClimb = true
                        }
                        if (edgeClimb) {
                            p.y -= dp(3)
                            if (p.y < dp(45)) { p.y = dp(45); edgeClimb = false; mode = 2 }
                        } else {
                            p.y = (p.y + dp(1)).coerceAtMost(maxY)
                        }
                    }
                    1 -> { /* sleeping: stay put */ }
                    2 -> {
                        p.x = (p.x + direction * dp(9)).coerceIn(0, maxX)
                        if (p.x == 0 || p.x == maxX) direction *= -1
                        if (ticks % 30 == 0) mode = 0
                    }
                }
                try { wm.updateViewLayout(dog, p) } catch (_: Exception) {}
            }
            ticks++
            frame = (frame + 1) % 8
            renderFrame()
            // Occasionally change behaviour without interrupting user dragging.
            if (!dragging && ticks % 95 == 0 && Random.nextInt(4) == 0) {
                mode = if (mode == 1) 0 else 1
            }
            handler.postDelayed(this, if (mode == 2) 95L else 180L)
        }
    }

    private val prank = object : Runnable {
        override fun run() {
            if (getSharedPreferences("dog", MODE_PRIVATE).getBoolean("pranks", false)
                && Random.nextInt(100) < 35) {
                val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(home) } catch (_: Exception) {
                    Toast.makeText(this@DogOverlayService, "¡El perro intentó una travesura!", Toast.LENGTH_SHORT).show()
                }
            }
            handler.postDelayed(this, Random.nextLong(5 * 60_000L, 12 * 60_000L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        makeChannel()
        startForeground(7, buildNotification())
        addDog()
        handler.post(loop)
        handler.postDelayed(prank, Random.nextLong(5 * 60_000L, 12 * 60_000L))
    }

    private fun makeChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("dog_channel", "Mascota", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "dog_channel")
            .setContentTitle("Annoying Dog está suelto")
            .setContentText("Toca aquí para abrir los controles")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(open).setOngoing(true).build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addDog() {
        val image = ImageView(this).apply {
            setImageBitmap(readFrame(0))
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        val size = dp(76)
        lp = WindowManager.LayoutParams(size, size,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(40); y = dp(230)
            }
        image.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true; downX = e.rawX; downY = e.rawY
                    originX = p.x; originY = p.y; true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = originX + (e.rawX - downX).toInt()
                    p.y = originY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(image, p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(e.rawX-downX) + kotlin.math.abs(e.rawY-downY)
                    dragging = false
                    if (moved < dp(12)) {
                        mode = (mode + 1) % 3
                        Toast.makeText(this, when(mode) {
                            1 -> "Zzz..."; 2 -> "¡WIIII!"; else -> "¡Guau!"
                        }, Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { dragging = false; true }
                else -> false
            }
        }
        dog = image
        wm.addView(image, lp)
    }

    private fun readFrame(i: Int) = assets.open("dog/frame_%02d.png".format(i % 22)).use {
        BitmapFactory.decodeStream(it)
    }

    private fun renderFrame() {
        try {
            // The supplied sheet contains several poses; cycle a small subset for a lightweight idle animation.
            val index = when (mode) {
                1 -> 16 + (frame % 4)
                2 -> 4 + (frame % 4)
                else -> frame
            }
            dog?.setImageBitmap(readFrame(index))
            dog?.scaleX = if (direction < 0) -1f else 1f
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        dog?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        dog = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
